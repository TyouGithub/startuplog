# StartupLog Android 安装说明

## 最简方法：PWABuilder（5分钟出APK）
1. 打开浏览器访问：https://www.pwabuilder.com
2. 在输入框中粘贴：
   https://tyougithub.github.io/startuplog/index.html
3. 点击「Start」
4. 选择「Android」→「Generate Package」
5. 下载 APK 文件，传到安卓手机安装

## 安装前置设置（安卓）
- 进入「设置 → 安全 → 安装未知应用」，允许浏览器或文件管理器安装

## 苹果手机（无需APK）
1. Safari 打开网址
2. 点击底部「分享」按钮 → 「添加到主屏幕」
3. 图标会出现在桌面，体验与原生 App 完全相同

---
应用信息：
- 包名：com.startuplog.app
- 启动地址：https://tyougithub.github.io/startuplog/index.html
- Android 最低版本：5.0 (API 21)
