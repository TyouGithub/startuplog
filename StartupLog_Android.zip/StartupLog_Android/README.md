# StartupLog Android 安装说明

## ★ 推荐方案：直接生成 APK（5分钟，无需谷歌浏览器）

### 方法一：用手机自带浏览器添加到桌面
1. 用手机**任意浏览器**（小米/华为/OPPO/三星自带浏览器均可）打开：
   https://tyougithub.github.io/startuplog/index.html
2. 点击菜单（三个点）→「添加到桌面」/「添加到主屏幕」
3. 桌面会出现 StartupLog 图标，点开后全屏运行

### 方法二：用本工程编译真正的原生 APK
需要安装 Android Studio（免费）：
1. 下载安装：https://developer.android.com/studio
2. 解压本 zip，用 Android Studio 打开 StartupLog_Android 文件夹
3. 等待 Gradle 同步（需联网，约3-5分钟）
4. 点击顶部菜单：Build → Build Bundle(s)/APK(s) → Build APK(s)
5. APK 文件在：app/build/outputs/apk/debug/app-debug.apk
6. 发到手机，点击安装（需开启「允许安装未知来源」）

### 方法三：PWABuilder 在线打包（最省事）
1. 访问 https://www.pwabuilder.com
2. 输入：https://tyougithub.github.io/startuplog/index.html
3. Android → Generate Package → 下载 APK

---
应用信息：包名 com.startuplog.app，最低 Android 5.0，竖屏全屏 WebView
